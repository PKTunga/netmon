from django.apps import AppConfig

class CaptivePortalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.captive_portal'
